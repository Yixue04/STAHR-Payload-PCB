*PADS-LIBRARY-SCH-DECALS-V9*

B5819WS-TP       32000 32000 100 10 100 10 4 6 0 2 8
TIMESTAMP 2020.10.26.07.09.43
"Default Font"
"Default Font"
500   350   0 8 100 10 "Default Font"
REF-DES
500   250   0 8 100 10 "Default Font"
PART-TYPE
500   -200  0 0 100 10 "Default Font"
*
500   -300  0 0 100 10 "Default Font"
*
COPCLS 4 10 0 -1
300   0    
500   100  
500   -100 
300   0    
OPEN   2 10 0 -1
300   100  
300   -100 
OPEN   3 10 0 -1
300   100  
340   100  
340   60   
OPEN   3 10 0 -1
300   -100 
260   -100 
260   -60  
OPEN   2 10 0 -1
200   0    
300   0    
OPEN   2 10 0 -1
500   0    
600   0    
T100   0     0 0 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0
T700   0     0 2 60    10    0 2 140   10    0 16 PINSHORT
P-520  0     0 2 -80   0     0 2 0


*END*